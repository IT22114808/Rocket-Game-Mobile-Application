package com.example.rocket

interface GameTask {

    fun closeGame(mScore:Int)

}





